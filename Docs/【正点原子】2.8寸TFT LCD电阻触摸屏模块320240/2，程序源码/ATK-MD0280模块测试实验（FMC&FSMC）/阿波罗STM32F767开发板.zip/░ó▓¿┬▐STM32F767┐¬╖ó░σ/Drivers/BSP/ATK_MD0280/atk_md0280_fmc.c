/**
 ****************************************************************************************************
 * @file        atk_md0280_fmc.c
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2022-06-21
 * @brief       ATK-MD0280ģ��FMC�ӿ���������
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� ������ F767������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#include "./BSP/ATK_MD0280/atk_md0280_fmc.h"

/* ATK-MD0280ģ��FMC��� */
static SRAM_HandleTypeDef g_sram_handle = {0};

/**
 * @brief       ATK-MD0280ģ��MPU����
 * @param       ��
 * @retval      ��
 */
void atk_md0280_mpu_config(void)
{
    MPU_Region_InitTypeDef mpu_initure;
    
    HAL_MPU_Disable();
    mpu_initure.Enable              = MPU_REGION_ENABLE;
    mpu_initure.Number              = MPU_REGION_NUMBER0;
    mpu_initure.BaseAddress         = ATK_MD0280_FMC_BANK_ADDR;
    mpu_initure.Size                = MPU_REGION_SIZE_256MB;
    mpu_initure.SubRegionDisable    = 0x00;
    mpu_initure.TypeExtField        = MPU_TEX_LEVEL0;
    mpu_initure.AccessPermission    = MPU_REGION_FULL_ACCESS;
    mpu_initure.DisableExec         = MPU_INSTRUCTION_ACCESS_ENABLE;
    mpu_initure.IsShareable         = MPU_ACCESS_NOT_SHAREABLE;
    mpu_initure.IsCacheable         = MPU_ACCESS_NOT_CACHEABLE;
    mpu_initure.IsBufferable        = MPU_ACCESS_BUFFERABLE;
    HAL_MPU_ConfigRegion(&mpu_initure);
    HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}

/**
 * @brief       ATK-MD0280ģ��FMC�ӿڳ�ʼ��
 * @param       ��
 * @retval      ��
 */
void atk_md0280_fmc_init(void)
{
    GPIO_InitTypeDef gpio_init_struct = {0};
    FMC_NORSRAM_TimingTypeDef read_timing = {0};
    FMC_NORSRAM_TimingTypeDef write_timing = {0};
    
    /* ʹ��ʱ�� */
    ATK_MD0280_FMC_CLK_ENABLE();
    ATK_MD0280_FMC_RS_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_CS_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_RD_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_WR_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D0_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D1_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D2_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D3_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D4_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D5_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D6_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D7_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D8_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D9_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D10_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D11_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D12_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D13_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D14_GPIO_CLK_ENABLE();
    ATK_MD0280_FMC_D15_GPIO_CLK_ENABLE();
    
    /* ��ʼ��RS���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_RS_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_RS_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_RS_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��CS���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_CS_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_CS_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_CS_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��RD���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_RD_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_RD_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_RD_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��WR���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_WR_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_WR_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_WR_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D0���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D0_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D0_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D0_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D1���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D1_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D1_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D1_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D2���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D2_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D2_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D2_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D3���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D3_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D3_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D3_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D4���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D4_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D4_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D4_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D5���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D5_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D5_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D5_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D6���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D6_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D6_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D6_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D7���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D7_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D7_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D7_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D8���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D8_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D8_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D8_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D9���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D9_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D9_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D9_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D10���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D10_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D10_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D10_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D11���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D11_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D11_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D11_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D12���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D12_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D12_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D12_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D13���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D13_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D13_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D13_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D14���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D14_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D14_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D14_GPIO_PORT, &gpio_init_struct);
    
    /* ��ʼ��D15���� */
    gpio_init_struct.Pin        = ATK_MD0280_FMC_D15_GPIO_PIN;
    gpio_init_struct.Mode       = GPIO_MODE_AF_PP;
    gpio_init_struct.Speed      = GPIO_SPEED_FREQ_HIGH;
    gpio_init_struct.Alternate  = ATK_MD0280_FMC_D15_GPIO_AF;
    HAL_GPIO_Init(ATK_MD0280_FMC_D15_GPIO_PORT, &gpio_init_struct);
    
    /* MPU���� */
    atk_md0280_mpu_config();
    
    /* FMC���� */
    g_sram_handle.Instance                  = FMC_NORSRAM_DEVICE;
    g_sram_handle.Extended                  = FMC_NORSRAM_EXTENDED_DEVICE;
    g_sram_handle.Init.NSBank               = ATK_MD0280_FMC_BANK;
    g_sram_handle.Init.DataAddressMux       = FMC_DATA_ADDRESS_MUX_DISABLE;
    g_sram_handle.Init.MemoryType           = FMC_MEMORY_TYPE_SRAM;
    g_sram_handle.Init.MemoryDataWidth      = FMC_NORSRAM_MEM_BUS_WIDTH_16;
    g_sram_handle.Init.BurstAccessMode      = FMC_BURST_ACCESS_MODE_DISABLE;
    g_sram_handle.Init.WaitSignalPolarity   = FMC_WAIT_SIGNAL_POLARITY_LOW;
    g_sram_handle.Init.WaitSignalActive     = FMC_WAIT_TIMING_BEFORE_WS;
    g_sram_handle.Init.WriteOperation       = FMC_WRITE_OPERATION_ENABLE;
    g_sram_handle.Init.WaitSignal           = FMC_WAIT_SIGNAL_DISABLE;
    g_sram_handle.Init.ExtendedMode         = FMC_EXTENDED_MODE_ENABLE;
    g_sram_handle.Init.AsynchronousWait     = FMC_ASYNCHRONOUS_WAIT_DISABLE;
    g_sram_handle.Init.WriteBurst           = FMC_WRITE_BURST_DISABLE;
    g_sram_handle.Init.ContinuousClock      = FMC_CONTINUOUS_CLOCK_SYNC_ONLY;
    g_sram_handle.Init.PageSize             = FMC_PAGE_SIZE_NONE;
    /* FMC��ʱ������ */
    read_timing.AddressSetupTime            = ATK_MD0280_FMC_READ_AST;
    read_timing.DataSetupTime               = ATK_MD0280_FMC_READ_DST;
    read_timing.BusTurnAroundDuration       = 0;
    read_timing.AccessMode                  = FMC_ACCESS_MODE_A;
    /* FMCдʱ������ */
    write_timing.AddressSetupTime           = ATK_MD0280_FMC_WRITE_AST;
    write_timing.DataSetupTime              = ATK_MD0280_FMC_WRITE_DST;
    write_timing.BusTurnAroundDuration      = 0;
    write_timing.AccessMode                 = FMC_ACCESS_MODE_A;
    /* ��ʼ��FMC */
    HAL_SRAM_Init(&g_sram_handle, &read_timing, &write_timing);
}
