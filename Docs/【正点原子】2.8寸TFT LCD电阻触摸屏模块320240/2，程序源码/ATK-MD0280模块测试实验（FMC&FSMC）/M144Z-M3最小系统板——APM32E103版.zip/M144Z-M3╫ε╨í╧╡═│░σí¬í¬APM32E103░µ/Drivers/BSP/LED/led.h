/**
 ****************************************************************************************************
 * @file        led.h
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2022-10-22
 * @brief       LED��������
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� APM32E103��Сϵͳ��
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 * 
 ****************************************************************************************************
 */

#ifndef __LED_H
#define __LED_H

#include "./SYSTEM/sys/sys.h"
#include "apm32e10x_gpio.h"

/* ���Ŷ��� */
#define LED0_GPIO_PORT          GPIOB
#define LED0_GPIO_PIN           GPIO_PIN_5
#define LED0_GPIO_CLK_ENABLE()  do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOB); }while(0)

#define LED1_GPIO_PORT          GPIOE
#define LED1_GPIO_PIN           GPIO_PIN_5
#define LED1_GPIO_CLK_ENABLE()  do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)

/* IO���� */
#define LED0(x)                 do{ x ? \
                                    (GPIO_SetBit(LED0_GPIO_PORT, LED0_GPIO_PIN)):       \
                                    (GPIO_ResetBit(LED0_GPIO_PORT, LED0_GPIO_PIN));     \
                                }while(0)

#define LED1(x)                 do{ x ? \
                                    (GPIO_SetBit(LED1_GPIO_PORT, LED1_GPIO_PIN)):       \
                                    (GPIO_ResetBit(LED1_GPIO_PORT, LED1_GPIO_PIN));     \
                                }while(0)

#define LED0_TOGGLE()           do{ GPIO_ReadOutputBit(LED0_GPIO_PORT, LED0_GPIO_PIN) ? \
                                    (GPIO_ResetBit(LED0_GPIO_PORT, LED0_GPIO_PIN)):     \
                                    (GPIO_SetBit(LED0_GPIO_PORT, LED0_GPIO_PIN));       \
                                }while(0)

#define LED1_TOGGLE()           do{ GPIO_ReadOutputBit(LED1_GPIO_PORT, LED1_GPIO_PIN) ? \
                                    (GPIO_ResetBit(LED1_GPIO_PORT, LED1_GPIO_PIN)):     \
                                    (GPIO_SetBit(LED1_GPIO_PORT, LED1_GPIO_PIN));       \
                                }while(0)

/* ��������*/
void led_init(void);    /* ��ʼ��LED */

#endif
