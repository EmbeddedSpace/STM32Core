/**
 ****************************************************************************************************
 * @file        atk_md0280_fsmc.h
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2022-06-21
 * @brief       ATK-MD0280ģ��FSMC�ӿ���������
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� APM32E103��Сϵͳ��
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 ****************************************************************************************************
 */

#ifndef __ATK_MD0280_FSMC_H
#define __ATK_MD0280_FSMC_H

#include "./SYSTEM/sys/sys.h"
#include "apm32e10x_gpio.h"

/* ATK-MD0280ģ��FSMC�ӿڶ��� */
#define ATK_MD0280_FSMC_BANK                    SMC_BANK1_NORSRAM_4                         /* ATK-MD0280ģ������FSMC��Bank */
#define ATK_MD0280_FSMC_BANK_ADDR               (0x6C000000)
#define ATK_MD0280_FSMC_REG_SEL                 (10)
#define ATK_MD0280_FSMC_READ_AST                0x0F                                        /* ��ʱ��ĵ�ַ����ʱ�䣬��λ��HCLK */
#define ATK_MD0280_FSMC_READ_DST                0x4E                                        /* ��ʱ������ݽ���ʱ�䣬��λ��HCLK */
#define ATK_MD0280_FSMC_WRITE_AST               0x01                                        /* дʱ��ĵ�ַ����ʱ�䣬��λ��HCLK */
#define ATK_MD0280_FSMC_WRITE_DST               0x0F                                        /* дʱ������ݽ���ʱ�䣬��λ��HCLK */
#define ATK_MD0280_FSMC_CLK_ENABLE()            do{ RCM_EnableAHBPeriphClock(RCM_AHB_PERIPH_SMC); }while(0)  /* ATK-MD0280ģ������FSMCʱ��ʹ�� */

/* ATK-MD0280ģ��FSMC�ӿڶ�д������ݵ�ַ */
#define ATK_MD0280_FSMC_CMD_ADDR                (ATK_MD0280_FSMC_BANK_ADDR | (((1U << ATK_MD0280_FSMC_REG_SEL) - 1) << 1))
#define ATK_MD0280_FSMC_DAT_ADDR                (ATK_MD0280_FSMC_BANK_ADDR | ((1U << ATK_MD0280_FSMC_REG_SEL) << 1))

/* ATK-MD0280ģ��FSMC�ӿڶ�д������� */
#define ATK_MD0280_FSMC_CMD_REG                 (*(volatile uint16_t *)ATK_MD0280_FSMC_CMD_ADDR)
#define ATK_MD0280_FSMC_DAT_REG                 (*(volatile uint16_t *)ATK_MD0280_FSMC_DAT_ADDR)

/* ���Ŷ��� */
#define ATK_MD0280_FSMC_RS_GPIO_PORT            GPIOG
#define ATK_MD0280_FSMC_RS_GPIO_PIN             GPIO_PIN_0
#define ATK_MD0280_FSMC_RS_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOG); }while(0)
#define ATK_MD0280_FSMC_CS_GPIO_PORT            GPIOG
#define ATK_MD0280_FSMC_CS_GPIO_PIN             GPIO_PIN_12
#define ATK_MD0280_FSMC_CS_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOG); }while(0)
#define ATK_MD0280_FSMC_RD_GPIO_PORT            GPIOD
#define ATK_MD0280_FSMC_RD_GPIO_PIN             GPIO_PIN_4
#define ATK_MD0280_FSMC_RD_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_WR_GPIO_PORT            GPIOD
#define ATK_MD0280_FSMC_WR_GPIO_PIN             GPIO_PIN_5
#define ATK_MD0280_FSMC_WR_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_D0_GPIO_PORT            GPIOD
#define ATK_MD0280_FSMC_D0_GPIO_PIN             GPIO_PIN_14
#define ATK_MD0280_FSMC_D0_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_D1_GPIO_PORT            GPIOD
#define ATK_MD0280_FSMC_D1_GPIO_PIN             GPIO_PIN_15
#define ATK_MD0280_FSMC_D1_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_D2_GPIO_PORT            GPIOD
#define ATK_MD0280_FSMC_D2_GPIO_PIN             GPIO_PIN_0
#define ATK_MD0280_FSMC_D2_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_D3_GPIO_PORT            GPIOD
#define ATK_MD0280_FSMC_D3_GPIO_PIN             GPIO_PIN_1
#define ATK_MD0280_FSMC_D3_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_D4_GPIO_PORT            GPIOE
#define ATK_MD0280_FSMC_D4_GPIO_PIN             GPIO_PIN_7
#define ATK_MD0280_FSMC_D4_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D5_GPIO_PORT            GPIOE
#define ATK_MD0280_FSMC_D5_GPIO_PIN             GPIO_PIN_8
#define ATK_MD0280_FSMC_D5_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D6_GPIO_PORT            GPIOE
#define ATK_MD0280_FSMC_D6_GPIO_PIN             GPIO_PIN_9
#define ATK_MD0280_FSMC_D6_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D7_GPIO_PORT            GPIOE
#define ATK_MD0280_FSMC_D7_GPIO_PIN             GPIO_PIN_10
#define ATK_MD0280_FSMC_D7_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D8_GPIO_PORT            GPIOE
#define ATK_MD0280_FSMC_D8_GPIO_PIN             GPIO_PIN_11
#define ATK_MD0280_FSMC_D8_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D9_GPIO_PORT            GPIOE
#define ATK_MD0280_FSMC_D9_GPIO_PIN             GPIO_PIN_12
#define ATK_MD0280_FSMC_D9_GPIO_CLK_ENABLE()    do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D10_GPIO_PORT           GPIOE
#define ATK_MD0280_FSMC_D10_GPIO_PIN            GPIO_PIN_13
#define ATK_MD0280_FSMC_D10_GPIO_CLK_ENABLE()   do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D11_GPIO_PORT           GPIOE
#define ATK_MD0280_FSMC_D11_GPIO_PIN            GPIO_PIN_14
#define ATK_MD0280_FSMC_D11_GPIO_CLK_ENABLE()   do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D12_GPIO_PORT           GPIOE
#define ATK_MD0280_FSMC_D12_GPIO_PIN            GPIO_PIN_15
#define ATK_MD0280_FSMC_D12_GPIO_CLK_ENABLE()   do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOE); }while(0)
#define ATK_MD0280_FSMC_D13_GPIO_PORT           GPIOD
#define ATK_MD0280_FSMC_D13_GPIO_PIN            GPIO_PIN_8
#define ATK_MD0280_FSMC_D13_GPIO_CLK_ENABLE()   do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_D14_GPIO_PORT           GPIOD
#define ATK_MD0280_FSMC_D14_GPIO_PIN            GPIO_PIN_9
#define ATK_MD0280_FSMC_D14_GPIO_CLK_ENABLE()   do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)
#define ATK_MD0280_FSMC_D15_GPIO_PORT           GPIOD
#define ATK_MD0280_FSMC_D15_GPIO_PIN            GPIO_PIN_10
#define ATK_MD0280_FSMC_D15_GPIO_CLK_ENABLE()   do{ RCM_EnableAPB2PeriphClock(RCM_APB2_PERIPH_GPIOD); }while(0)

/* �������� */
void atk_md0280_fsmc_init(void);                                                            /* ATK-MD0280ģ��FSMC�ӿڳ�ʼ�� */
static inline void atk_md0280_fsmc_write_cmd(volatile uint16_t cmd)                         /* ATK-MD0280ģ��ͨ��FSMC�ӿ�д���� */
{
    ATK_MD0280_FSMC_CMD_REG = cmd;
}
static inline void atk_md0280_fsmc_write_dat(volatile uint16_t dat)                         /* ATK-MD0280ģ��ͨ��FSMC�ӿ�д���� */
{
    ATK_MD0280_FSMC_DAT_REG = dat;
}
static inline void atk_md0280_fsmc_write_reg(volatile uint16_t reg, volatile uint16_t dat)  /* ATK-MD0280ģ��ͨ��FSMC�ӿ�д�Ĵ��� */
{
    ATK_MD0280_FSMC_CMD_REG = reg;
    ATK_MD0280_FSMC_DAT_REG = dat;
}
static inline uint16_t atk_md0280_fsmc_read_dat(void)                              /* ATK-MD0280ģ��ͨ��FSMC�ӿڶ����� */
{
    uint16_t dat;
    
    __nop();
    __nop();
    dat = ATK_MD0280_FSMC_DAT_REG;
    
    return dat;
}

#endif
